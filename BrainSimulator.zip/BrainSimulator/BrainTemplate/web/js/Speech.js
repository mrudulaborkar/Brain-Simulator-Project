// JavaScript Document

function speakLoud()
{
	var Obj = new ActiveXObject("Sapi.SpVoice");
	var string=document.getElementById("t1").value;
	alert("You have entered"+string);
	Obj.Speak(string, 1 );
}